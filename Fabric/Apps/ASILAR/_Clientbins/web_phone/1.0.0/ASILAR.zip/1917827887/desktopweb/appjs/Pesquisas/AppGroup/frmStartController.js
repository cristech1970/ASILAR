define("Pesquisas/AppGroup/userfrmStartController", {
    //Type your controller code here 
});
define("Pesquisas/AppGroup/frmStartControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_he687de6c41b498d93c2d0c591a4b0ee: function AS_Button_he687de6c41b498d93c2d0c591a4b0ee(eventobject) {
        var self = this;
        voltmx.application.showLoadingScreen(null, "Aguarde", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        var self = this;

        function INVOKE_SERVICE_f4448dfa576342eb96f98894f7ba63f0_Callback(pesquisa) {
            voltmx.application.dismissLoadingScreen();
            id = pesquisa.id;
            var ntf = new voltmx.mvc.Navigation("frmQuestoes");
            ntf.navigate();
        }
        voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        var hoje = new Date();
        dataAtual = hoje.toLocaleDateString();
        if (pesquisa_inputparam == undefined) {
            var pesquisa_inputparam = {};
        }
        pesquisa_inputparam["serviceID"] = "asilarDb$pesquisa$create";
        pesquisa_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "create"
        };
        var data = {};
        data["DataCriacao"] = dataAtual;
        pesquisa_inputparam["options"]["data"] = data;
        var pesquisa_httpheaders = {};
        pesquisa_inputparam["httpheaders"] = pesquisa_httpheaders;
        var pesquisa_httpconfigs = {};
        pesquisa_inputparam["httpconfig"] = pesquisa_httpconfigs;
        asilarDb$pesquisa$create = mfobjectsecureinvokerasync(pesquisa_inputparam, "asilarDb", "pesquisa", INVOKE_SERVICE_f4448dfa576342eb96f98894f7ba63f0_Callback);
    }
});
define("Pesquisas/AppGroup/frmStartController", ["Pesquisas/AppGroup/userfrmStartController", "Pesquisas/AppGroup/frmStartControllerActions"], function() {
    var controller = require("Pesquisas/AppGroup/userfrmStartController");
    var controllerActions = ["Pesquisas/AppGroup/frmStartControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
