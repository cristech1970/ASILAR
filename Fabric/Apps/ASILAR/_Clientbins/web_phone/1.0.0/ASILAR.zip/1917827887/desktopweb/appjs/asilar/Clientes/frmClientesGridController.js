define("Asilar/Clientes/userfrmClientesGridController", {
    //Type your controller code here 
});
define("Asilar/Clientes/frmClientesGridControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_c589d4f514584aba8fe53f0b784599bf: function AS_Button_c589d4f514584aba8fe53f0b784599bf(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "Asilar",
            "friendlyName": "Clientes/frmClientesCreate"
        });
        ntf.navigate();
    },
    AS_Form_ed02903674eb42329b68756f458f240e: function AS_Form_ed02903674eb42329b68756f458f240e(eventobject, breakpoint) {
        var self = this;
        if ([640].indexOf(kony.application.getCurrentBreakpoint()) !== -1) {
            self.view.flexClientes.isVisible = false;
            var templateId = self.view.segClientes.rowTemplate;
            self.view.segClientes.data.forEach(function(row) {
                row[templateId] = {
                    layoutType: kony.flex.FLOW_VERTICAL
                };
                Object.keys(row).forEach(function(key) {
                    if (key.includes("lbl")) {
                        row[key].width = '80%';
                        row[key].height = kony.flex.USE_PREFERRED_SIZE;
                    }
                });
            });
            var clonedWidgetDataMap = self.view.segClientes.widgetDataMap;
            clonedWidgetDataMap[templateId] = templateId;
            self.view.segClientes.widgetDataMap = clonedWidgetDataMap;
            self.view.segClientes.setData(self.view.segClientes.data);
            self.view.forceLayout();
        } else {
            self.view.flexClientes.isVisible = true;
            var templateId = self.view.segClientes.rowTemplate;
            self.view.segClientes.data.forEach(function(row) {
                row[templateId] = {
                    layoutType: kony.flex.FLOW_HORIZONTAL
                };
                Object.keys(row).forEach(function(key) {
                    if (key.includes("lbl")) {
                        row[key].width = '2.5%';
                        row[key].height = "";
                    }
                });
            });
            var clonedWidgetDataMap = self.view.segClientes.widgetDataMap;
            clonedWidgetDataMap[templateId] = templateId;
            self.view.segClientes.widgetDataMap = clonedWidgetDataMap;
            self.view.segClientes.setData(self.view.segClientes.data);
            self.view.forceLayout();
        }
    },
    AS_Form_ba3caec1acc44b4298d464824af6a78f: function AS_Form_ba3caec1acc44b4298d464824af6a78f(eventobject) {
        var self = this;

        function SHOW_ALERT_fc426291bd5a4a898d9c34625a72911d_True() {}

        function INVOKE_OBJECT_SERVICE_cad34f36603f46e1a2cb3f6251bcdd0c_Callback(Clientes) {
            voltmx.application.dismissLoadingScreen();
            if (Clientes.opstatus == 0) {
                var tempCollection4225 = [];
                var tempData4332 = Clientes.records;
                for (var each5103 in tempData4332) {
                    tempCollection4225.push({
                        "lblId1": {
                            "text": voltmx.visualizer.toString(tempData4332[each5103]["Id"])
                        },
                        "lblInativoData1": {
                            "text": voltmx.visualizer.toCalendarDateFormat(tempData4332[each5103]["InativoData"])
                        },
                        "lblInativoMotivo1": {
                            "text": tempData4332[each5103]["InativoMotivo"]
                        },
                        "lblObitoDocumento1": {
                            "text": tempData4332[each5103]["ObitoDocumento"]
                        },
                        "lblInativoDetalhes1": {
                            "text": tempData4332[each5103]["InativoDetalhes"]
                        },
                        "lblNacionalidade1": {
                            "text": tempData4332[each5103]["Nacionalidade"]
                        },
                        "lblNaturalidade1": {
                            "text": tempData4332[each5103]["Naturalidade"]
                        },
                        "lblPai1": {
                            "text": tempData4332[each5103]["Pai"]
                        },
                        "lblMae1": {
                            "text": tempData4332[each5103]["Mae"]
                        },
                        "lblCivil1": {
                            "text": tempData4332[each5103]["Civil"]
                        },
                        "lblRG1": {
                            "text": tempData4332[each5103]["RG"]
                        },
                        "lblCPF1": {
                            "text": tempData4332[each5103]["CPF"]
                        },
                        "lblSUS1": {
                            "text": tempData4332[each5103]["SUS"]
                        },
                        "lblTituloEleitor1": {
                            "text": tempData4332[each5103]["TituloEleitor"]
                        },
                        "lblInterditado1": {
                            "text": tempData4332[each5103]["Interditado"]
                        },
                        "lblInterditadoCurador1": {
                            "text": tempData4332[each5103]["InterditadoCurador"]
                        },
                        "lblInterditadoData1": {
                            "text": voltmx.visualizer.toCalendarDateFormat(tempData4332[each5103]["InterditadoData"])
                        },
                        "lblInterditadoCuradorTelefone1": {
                            "text": tempData4332[each5103]["InterditadoCuradorTelefone"]
                        },
                        "lblInterditadoCuradorEmail1": {
                            "text": tempData4332[each5103]["InterditadoCuradorEmail"]
                        },
                        "lblControleCaixaFlag1": {
                            "text": tempData4332[each5103]["ControleCaixaFlag"]
                        },
                        "lblEvangelicoFlag1": {
                            "text": tempData4332[each5103]["EvangelicoFlag"]
                        },
                        "lblEvangelicoTipo1": {
                            "text": tempData4332[each5103]["EvangelicoTipo"]
                        },
                        "lblEvangelicoSetor1": {
                            "text": tempData4332[each5103]["EvangelicoSetor"]
                        },
                        "lblEvangelicoPastor1": {
                            "text": tempData4332[each5103]["EvangelicoPastor"]
                        },
                        "lblEvangelicoMinisterio1": {
                            "text": tempData4332[each5103]["EvangelicoMinisterio"]
                        },
                        "lblEvangelicoDenominacao1": {
                            "text": tempData4332[each5103]["EvangelicoDenominacao"]
                        },
                        "lblEvangelicoAceiteJesusAsilar1": {
                            "text": tempData4332[each5103]["EvangelicoAceiteJesusAsilar"]
                        },
                        "lblEvangelicoDetalhes1": {
                            "text": tempData4332[each5103]["EvangelicoDetalhes"]
                        },
                        "lblMotivoAbrigamento1": {
                            "text": tempData4332[each5103]["MotivoAbrigamento"]
                        },
                        "lblMotivoEscolha1": {
                            "text": tempData4332[each5103]["MotivoEscolha"]
                        },
                    });
                }
                self.view.segClientes.setData(tempCollection4225);
                if ([640].indexOf(kony.application.getCurrentBreakpoint()) !== -1) {
                    var templateId = self.view.segClientes.rowTemplate;
                    self.view.segClientes.data.forEach(function(row) {
                        row[templateId] = {
                            layoutType: kony.flex.FLOW_VERTICAL
                        };
                        Object.keys(row).forEach(function(key) {
                            if (key.includes("lbl")) {
                                row[key].width = '80%';
                                row[key].height = kony.flex.USE_PREFERRED_SIZE;
                            }
                        });
                    });
                    var clonedWidgetDataMap = self.view.segClientes.widgetDataMap;
                    clonedWidgetDataMap[templateId] = templateId;
                    self.view.segClientes.widgetDataMap = clonedWidgetDataMap;
                    self.view.segClientes.setData(self.view.segClientes.data);
                    self.view.forceLayout();
                }
            } else {
                function SHOW_ALERT_fc426291bd5a4a898d9c34625a72911d_Callback() {
                    SHOW_ALERT_fc426291bd5a4a898d9c34625a72911d_True();
                }
                voltmx.ui.Alert({
                    "alertType": constants.ALERT_TYPE_INFO,
                    "alertTitle": null,
                    "yesLabel": null,
                    "noLabel": null,
                    "alertIcon": null,
                    "message": "Data fetch failed! Please try again later.",
                    "alertHandler": SHOW_ALERT_fc426291bd5a4a898d9c34625a72911d_Callback
                }, {
                    "iconPosition": constants.ALERT_ICON_POSITION_LEFT
                });
            }
        }
        voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        if (Clientes_inputparam == undefined) {
            var Clientes_inputparam = {};
        }
        Clientes_inputparam["serviceID"] = "AsilarBD$Clientes$get";
        Clientes_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "get"
        };
        var Clientes_httpheaders = {};
        Clientes_inputparam["httpheaders"] = Clientes_httpheaders;
        var Clientes_httpconfigs = {};
        Clientes_inputparam["httpconfig"] = Clientes_httpconfigs;
        AsilarBD$Clientes$get = mfobjectsecureinvokerasync(Clientes_inputparam, "AsilarBD", "Clientes", INVOKE_OBJECT_SERVICE_cad34f36603f46e1a2cb3f6251bcdd0c_Callback);
    },
    AS_Segment_add23c98204b4a0bb56d9025a7463b20: function AS_Segment_add23c98204b4a0bb56d9025a7463b20(eventobject, sectionNumber, rowNumber) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "Asilar",
            "friendlyName": "Clientes/frmClientesDetails"
        });
        ntf.navigate({
            "segClientes_lblId1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblId1"], "text"),
            "segClientes_lblInativoData1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblInativoData1"], "text"),
            "segClientes_lblInativoMotivo1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblInativoMotivo1"], "text"),
            "segClientes_lblObitoDocumento1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblObitoDocumento1"], "text"),
            "segClientes_lblInativoDetalhes1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblInativoDetalhes1"], "text"),
            "segClientes_lblNacionalidade1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblNacionalidade1"], "text"),
            "segClientes_lblNaturalidade1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblNaturalidade1"], "text"),
            "segClientes_lblPai1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblPai1"], "text"),
            "segClientes_lblMae1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblMae1"], "text"),
            "segClientes_lblCivil1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblCivil1"], "text"),
            "segClientes_lblRG1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblRG1"], "text"),
            "segClientes_lblCPF1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblCPF1"], "text"),
            "segClientes_lblSUS1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblSUS1"], "text"),
            "segClientes_lblTituloEleitor1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblTituloEleitor1"], "text"),
            "segClientes_lblInterditado1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblInterditado1"], "text"),
            "segClientes_lblInterditadoCurador1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblInterditadoCurador1"], "text"),
            "segClientes_lblInterditadoData1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblInterditadoData1"], "text"),
            "segClientes_lblInterditadoCuradorTelefone1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblInterditadoCuradorTelefone1"], "text"),
            "segClientes_lblInterditadoCuradorEmail1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblInterditadoCuradorEmail1"], "text"),
            "segClientes_lblControleCaixaFlag1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblControleCaixaFlag1"], "text"),
            "segClientes_lblEvangelicoFlag1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblEvangelicoFlag1"], "text"),
            "segClientes_lblEvangelicoTipo1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblEvangelicoTipo1"], "text"),
            "segClientes_lblEvangelicoSetor1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblEvangelicoSetor1"], "text"),
            "segClientes_lblEvangelicoPastor1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblEvangelicoPastor1"], "text"),
            "segClientes_lblEvangelicoMinisterio1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblEvangelicoMinisterio1"], "text"),
            "segClientes_lblEvangelicoDenominacao1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblEvangelicoDenominacao1"], "text"),
            "segClientes_lblEvangelicoAceiteJesusAsilar1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblEvangelicoAceiteJesusAsilar1"], "text"),
            "segClientes_lblEvangelicoDetalhes1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblEvangelicoDetalhes1"], "text"),
            "segClientes_lblMotivoAbrigamento1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblMotivoAbrigamento1"], "text"),
            "segClientes_lblMotivoEscolha1": voltmx.visualizer.getPropertyValue(self.view.segClientes.selectedRowItems[0]["lblMotivoEscolha1"], "text"),
            "_meta_": {
                "eventName": "onRowClick",
                "widgetId": "segClientes"
            }
        });
    }
});
define("Asilar/Clientes/frmClientesGridController", ["Asilar/Clientes/userfrmClientesGridController", "Asilar/Clientes/frmClientesGridControllerActions"], function() {
    var controller = require("Asilar/Clientes/userfrmClientesGridController");
    var controllerActions = ["Asilar/Clientes/frmClientesGridControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
