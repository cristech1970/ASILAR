define("Asilar/userFBoxClientesController", {
    //Type your controller code here 
});
define("Asilar/FBoxClientesControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Asilar/FBoxClientesController", ["Asilar/userFBoxClientesController", "Asilar/FBoxClientesControllerActions"], function() {
    var controller = require("Asilar/userFBoxClientesController");
    var controllerActions = ["Asilar/FBoxClientesControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
