define("PreCadastro/AppGroup/userfrmLoginController", {
    //Type your controller code here 
});
define("PreCadastro/AppGroup/frmLoginControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_da5465136c1649429370d951a3dcc83a: function AS_Button_da5465136c1649429370d951a3dcc83a(eventobject) {
        var self = this;

        function INVOKE_SERVICE_e0b50c5c3e6041559db0cae6e402b66f_Success(response) {
            var ntf = new voltmx.mvc.Navigation("undefined");
            ntf.navigate();
        }

        function INVOKE_SERVICE_e0b50c5c3e6041559db0cae6e402b66f_Failure(error) {
            function SHOW_ALERT_c6643836f5b54158a93491684552358f_Callback() {
                SHOW_ALERT_c6643836f5b54158a93491684552358f_True();
            }
            voltmx.ui.Alert({
                "alertType": constants.ALERT_TYPE_ERROR,
                "alertTitle": "Erro",
                "yesLabel": "OK",
                "message": "Usuário ou senha errados",
                "alertHandler": SHOW_ALERT_c6643836f5b54158a93491684552358f_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }

        function SHOW_ALERT_c6643836f5b54158a93491684552358f_True() {}
        if (login_inputparam == undefined) {
            var login_inputparam = {};
        }
        login_inputparam["serviceID"] = "DiretorioAsilar$login";
        login_inputparam["operation"] = "login";
        login_inputparam["userid"] = self.view.txtUserName.text;
        login_inputparam["password"] = self.view.txtPassword.text;
        DiretorioAsilar$login = mfidentityserviceinvoker("DiretorioAsilar", login_inputparam, INVOKE_SERVICE_e0b50c5c3e6041559db0cae6e402b66f_Success, INVOKE_SERVICE_e0b50c5c3e6041559db0cae6e402b66f_Failure);
    }
});
define("PreCadastro/AppGroup/frmLoginController", ["PreCadastro/AppGroup/userfrmLoginController", "PreCadastro/AppGroup/frmLoginControllerActions"], function() {
    var controller = require("PreCadastro/AppGroup/userfrmLoginController");
    var controllerActions = ["PreCadastro/AppGroup/frmLoginControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
