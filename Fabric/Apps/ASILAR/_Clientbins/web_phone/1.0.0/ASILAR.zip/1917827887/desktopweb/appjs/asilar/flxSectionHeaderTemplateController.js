define("Asilar/userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("Asilar/flxSectionHeaderTemplateControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Asilar/flxSectionHeaderTemplateController", ["Asilar/userflxSectionHeaderTemplateController", "Asilar/flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("Asilar/userflxSectionHeaderTemplateController");
    var controllerActions = ["Asilar/flxSectionHeaderTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
