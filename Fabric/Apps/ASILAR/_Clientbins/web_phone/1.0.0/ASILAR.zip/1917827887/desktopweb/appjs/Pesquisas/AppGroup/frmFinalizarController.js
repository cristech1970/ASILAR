define("Pesquisas/AppGroup/userfrmFinalizarController", {
    //Type your controller code here 
});
define("Pesquisas/AppGroup/frmFinalizarControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_hf9869f14f1d4b18bce12aaba29e7aee: function AS_Button_hf9869f14f1d4b18bce12aaba29e7aee(eventobject) {
        var self = this;
        voltmx.application.showLoadingScreen(null, "Aguarde", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        var self = this;

        function INVOKE_SERVICE_b7eb9ac99c2143ba8a7385338fa1472c_Callback(pesquisa) {
            voltmx.application.dismissLoadingScreen();
            var ntf = new voltmx.mvc.Navigation("frmAgradecimento");
            ntf.navigate();
        }
        if (pesquisa_inputparam == undefined) {
            var pesquisa_inputparam = {};
        }
        pesquisa_inputparam["serviceID"] = "asilarDb$pesquisa$update";
        pesquisa_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "update"
        };
        var data = {};
        data["id"] = id;
        data["TextFieldNome"] = self.view.TextFieldNome.text;
        data["TextFieldParenteAbrigado"] = self.view.TextFieldParenteAbrigado.text;
        data["TextFieldTelefone"] = self.view.TextFieldTelefone.text;
        data["TextFieldEmail"] = self.view.TextFieldEmail.text;
        pesquisa_inputparam["options"]["data"] = data;
        var pesquisa_httpheaders = {};
        pesquisa_inputparam["httpheaders"] = pesquisa_httpheaders;
        var pesquisa_httpconfigs = {};
        pesquisa_inputparam["httpconfig"] = pesquisa_httpconfigs;
        asilarDb$pesquisa$update = mfobjectsecureinvokerasync(pesquisa_inputparam, "asilarDb", "pesquisa", INVOKE_SERVICE_b7eb9ac99c2143ba8a7385338fa1472c_Callback);
    }
});
define("Pesquisas/AppGroup/frmFinalizarController", ["Pesquisas/AppGroup/userfrmFinalizarController", "Pesquisas/AppGroup/frmFinalizarControllerActions"], function() {
    var controller = require("Pesquisas/AppGroup/userfrmFinalizarController");
    var controllerActions = ["Pesquisas/AppGroup/frmFinalizarControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
