define("Asilar/FBoxClientes", function() {
    return function(controller) {
        FBoxClientes = new voltmx.ui.FlexContainer({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "clipBounds": false,
            "id": "FBoxClientes",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0%",
            "isModalContainer": false,
            "skin": "s7bc2a403eb4406ea845f300d40fa9c4",
            "top": "0%",
            "width": "100%",
            "appName": "Asilar"
        }, {
            "paddingInPixel": false
        }, {});
        FBoxClientes.setDefaultUnit(voltmx.flex.DP);
        var lblId1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblId1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "Id",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblInativoData1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblInativoData1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "InativoData",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblInativoMotivo1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblInativoMotivo1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "InativoMotivo",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblObitoDocumento1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblObitoDocumento1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "ObitoDocumento",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblInativoDetalhes1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblInativoDetalhes1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "InativoDetalhes",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblNacionalidade1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblNacionalidade1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "Nacionalidade",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblNaturalidade1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblNaturalidade1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "Naturalidade",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblPai1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblPai1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "Pai",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblMae1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblMae1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "Mae",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblCivil1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblCivil1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "Civil",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblRG1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblRG1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "RG",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblCPF1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblCPF1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "CPF",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblSUS1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblSUS1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "SUS",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblTituloEleitor1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblTituloEleitor1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "TituloEleitor",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblInterditado1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblInterditado1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "Interditado",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblInterditadoCurador1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblInterditadoCurador1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "InterditadoCurador",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblInterditadoData1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblInterditadoData1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "InterditadoData",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblInterditadoCuradorTelefone1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblInterditadoCuradorTelefone1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "InterditadoCuradorTelefone",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblInterditadoCuradorEmail1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblInterditadoCuradorEmail1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "InterditadoCuradorEmail",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblControleCaixaFlag1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblControleCaixaFlag1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "ControleCaixaFlag",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblEvangelicoFlag1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblEvangelicoFlag1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "EvangelicoFlag",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblEvangelicoTipo1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblEvangelicoTipo1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "EvangelicoTipo",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblEvangelicoSetor1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblEvangelicoSetor1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "EvangelicoSetor",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblEvangelicoPastor1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblEvangelicoPastor1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "EvangelicoPastor",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblEvangelicoMinisterio1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblEvangelicoMinisterio1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "EvangelicoMinisterio",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblEvangelicoDenominacao1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblEvangelicoDenominacao1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "EvangelicoDenominacao",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblEvangelicoAceiteJesusAsilar1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblEvangelicoAceiteJesusAsilar1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "EvangelicoAceiteJesusAsilar",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblEvangelicoDetalhes1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblEvangelicoDetalhes1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "EvangelicoDetalhes",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblMotivoAbrigamento1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblMotivoAbrigamento1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "MotivoAbrigamento",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        var lblMotivoEscolha1 = new voltmx.ui.Label({
            "bottom": "0dp",
            "id": "lblMotivoEscolha1",
            "isVisible": true,
            "left": "0%",
            "skin": "defDataPanelLabelSubHeadingDW",
            "text": "MotivoEscolha",
            "top": "5dp",
            "width": "2.5%"
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 1, 0, 1],
            "paddingInPixel": false
        }, {});
        FBoxClientes.add(lblId1, lblInativoData1, lblInativoMotivo1, lblObitoDocumento1, lblInativoDetalhes1, lblNacionalidade1, lblNaturalidade1, lblPai1, lblMae1, lblCivil1, lblRG1, lblCPF1, lblSUS1, lblTituloEleitor1, lblInterditado1, lblInterditadoCurador1, lblInterditadoData1, lblInterditadoCuradorTelefone1, lblInterditadoCuradorEmail1, lblControleCaixaFlag1, lblEvangelicoFlag1, lblEvangelicoTipo1, lblEvangelicoSetor1, lblEvangelicoPastor1, lblEvangelicoMinisterio1, lblEvangelicoDenominacao1, lblEvangelicoAceiteJesusAsilar1, lblEvangelicoDetalhes1, lblMotivoAbrigamento1, lblMotivoEscolha1);
        return FBoxClientes;
    }
})