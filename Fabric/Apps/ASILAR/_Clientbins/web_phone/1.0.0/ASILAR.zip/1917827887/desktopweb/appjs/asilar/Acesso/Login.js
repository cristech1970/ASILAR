define("Asilar/Acesso/Login", function() {
    return function(controller) {
        function addWidgetsLogin() {
            this.setDefaultUnit(voltmx.flex.DP);
            var flexlogin = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "500dp",
                "id": "flexlogin",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "35%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "zIndex": 1,
                "appName": "Asilar"
            }, {
                "paddingInPixel": false
            }, {});
            flexlogin.setDefaultUnit(voltmx.flex.DP);
            var imgLogin = new voltmx.ui.Image2({
                "bottom": "65dp",
                "centerX": "50%",
                "height": "150dp",
                "id": "imgLogin",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "logo.jpg",
                "top": "0dp",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxuserid = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "focusSkin": "defDataPanelTextBoxFocus",
                "height": "50dp",
                "id": "tbxuserid",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "placeholder": "User name",
                "secureTextEntry": false,
                "skin": "defDataPanelLoginTextBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "90%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defDataPanelTextBoxPlaceholder"
            });
            var tbxpassword = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "focusSkin": "defDataPanelTextBoxFocus",
                "height": "50dp",
                "id": "tbxpassword",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "placeholder": "Password",
                "secureTextEntry": true,
                "skin": "defDataPanelLoginTextBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "90%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defDataPanelTextBoxPlaceholder"
            });
            var btnLOGIN = new voltmx.ui.Button({
                "bottom": "10dp",
                "centerX": "50%",
                "focusSkin": "defDataPanelLoginBtnActive",
                "height": "60dp",
                "id": "btnLOGIN",
                "isVisible": true,
                "onClick": controller.AS_Button_f7b6890f2bc041a3bbffe0d26dbac27d,
                "skin": "defDataPanelLoginBtnNormal",
                "text": "LOGIN",
                "top": "50dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flexlogin.add(imgLogin, tbxuserid, tbxpassword, btnLOGIN);
            this.compInstData = {}
            this.add(flexlogin);
        };
        return [{
            "addWidgets": addWidgetsLogin,
            "enabledForIdleTimeout": false,
            "id": "Login",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "Asilar"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});