define("Pesquisas/AppGroup/frmAgradecimento", function() {
    return function(controller) {
        function addWidgetsfrmAgradecimento() {
            this.setDefaultUnit(voltmx.flex.DP);
            var Label0de51df2b55a94f = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "Label0de51df2b55a94f",
                "isVisible": true,
                "skin": "defLabel",
                "text": "Obrigado!",
                "textStyle": {},
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(Label0de51df2b55a94f);
        };
        return [{
            "addWidgets": addWidgetsfrmAgradecimento,
            "enabledForIdleTimeout": false,
            "id": "frmAgradecimento",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "Pesquisas"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});