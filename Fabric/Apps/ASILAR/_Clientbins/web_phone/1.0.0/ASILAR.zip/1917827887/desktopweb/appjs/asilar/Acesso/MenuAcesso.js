define("Asilar/Acesso/MenuAcesso", function() {
    return function(controller) {
        function addWidgetsMenuAcesso() {
            this.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0afcfa05976f14c = new voltmx.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "FlexContainer0afcfa05976f14c",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 11,
                        "1366": 12
                    }
                },
                "appName": "Asilar"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0afcfa05976f14c.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0b7c9f6d75b844e = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "90%",
                "id": "FlexContainer0b7c9f6d75b844e",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "293dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "84dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "Asilar"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0b7c9f6d75b844e.setDefaultUnit(voltmx.flex.DP);
            var Label0dae5e78e87ee47 = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "Label0dae5e78e87ee47",
                "isVisible": true,
                "skin": "defLabel",
                "text": "Acesso as aplicações",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0b7c9f6d75b844e.add(Label0dae5e78e87ee47);
            FlexContainer0afcfa05976f14c.add(FlexContainer0b7c9f6d75b844e);
            var FlexContainer0fb932732e53542 = new voltmx.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "FlexContainer0fb932732e53542",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "Asilar"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0fb932732e53542.setDefaultUnit(voltmx.flex.DP);
            var FlexContainerBtnAbrigados = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "90%",
                "id": "FlexContainerBtnAbrigados",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "97dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_c7ed56f2de584c92ae56c2f14fae0bc2,
                "skin": "slFbox",
                "top": "108dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "Asilar"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainerBtnAbrigados.setDefaultUnit(voltmx.flex.DP);
            var Image0b65ba010d2c446 = new voltmx.ui.Image2({
                "height": "100%",
                "id": "Image0b65ba010d2c446",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "idosos.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainerBtnAbrigados.add(Image0b65ba010d2c446);
            FlexContainer0fb932732e53542.add(FlexContainerBtnAbrigados);
            this.compInstData = {}
            this.add(FlexContainer0afcfa05976f14c, FlexContainer0fb932732e53542);
        };
        return [{
            "addWidgets": addWidgetsMenuAcesso,
            "enabledForIdleTimeout": false,
            "id": "MenuAcesso",
            "layoutType": voltmx.flex.RESPONSIVE_GRID,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "Asilar"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.RESPONSIVE_GRID,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});