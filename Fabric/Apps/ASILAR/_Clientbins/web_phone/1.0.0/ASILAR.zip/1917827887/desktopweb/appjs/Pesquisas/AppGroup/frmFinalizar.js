define("Pesquisas/AppGroup/frmFinalizar", function() {
    return function(controller) {
        function addWidgetsfrmFinalizar() {
            this.setDefaultUnit(voltmx.flex.DP);
            var nav = new asilar.nav({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "70dp",
                "id": "nav",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "Pesquisas",
                "overrides": {
                    "nav": {
                        "centerX": "50%",
                        "centerY": "viz.val_cleared",
                        "top": "0dp",
                        "width": "90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var FlexContainer09 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "60%",
                "id": "FlexContainer09",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox1",
                "top": "15dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer09.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0b89905b1eeaa43 = new voltmx.ui.Label({
                "height": "150dp",
                "id": "CopyLabel0b89905b1eeaa43",
                "isVisible": true,
                "left": "0%",
                "skin": "defLabel3",
                "text": "Muito obrigado.  \n\nNão deixe de interceder a Deus em favor dos Cuidadores e Abrigados. Não se acanhe em contribuir com qualquer valor para o ASILAR – PIX 63.094.429/0001-05. \n\nSe tiver alguma reclamação a fazer pode se utilizar do email: diretorexecutivoasilar@gmail.com",
                "textStyle": {},
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var Label0b56c0b3b7e8a4f = new voltmx.ui.Label({
                "id": "Label0b56c0b3b7e8a4f",
                "isVisible": true,
                "left": "2%",
                "skin": "defLabel2",
                "text": "Seu nome:",
                "top": "15dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldNome = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "TextFieldNome",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "secureTextEntry": false,
                "skin": "defTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var Label0ae494d40ed6f4b = new voltmx.ui.Label({
                "id": "Label0ae494d40ed6f4b",
                "isVisible": true,
                "left": "2%",
                "skin": "defLabel2",
                "text": "Nome de seu parente abrigado:",
                "textStyle": {},
                "top": "20dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyLabel0he4d96fd54264a = new voltmx.ui.Label({
                "id": "CopyLabel0he4d96fd54264a",
                "isVisible": true,
                "left": "2%",
                "skin": "CopydefLabel0a27cace456b44b",
                "text": "Se foi visitar o Lar, informe apenas ASILAR.",
                "textStyle": {},
                "top": "2dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldParenteAbrigado = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "TextFieldParenteAbrigado",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "secureTextEntry": false,
                "skin": "defTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var CopyLabel0eae5aa3bb11a4d = new voltmx.ui.Label({
                "id": "CopyLabel0eae5aa3bb11a4d",
                "isVisible": true,
                "left": "2%",
                "skin": "defLabel2",
                "text": "Telefone:",
                "top": "20dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldTelefone = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "TextFieldTelefone",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "maxTextLength": 11,
                "placeholder": "(99) 99999-9999 ",
                "secureTextEntry": false,
                "skin": "defTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "48%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var CopyLabel0j8d66f61efeb4e = new voltmx.ui.Label({
                "id": "CopyLabel0j8d66f61efeb4e",
                "isVisible": true,
                "left": "2%",
                "skin": "defLabel2",
                "text": "Email:",
                "top": "20dp",
                "width": voltmx.flex.USE_PREFERRED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextFieldEmail = new voltmx.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "TextFieldEmail",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_EMAIL,
                "left": "2%",
                "secureTextEntry": false,
                "skin": "defTextBoxNormal1",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            FlexContainer09.add(CopyLabel0b89905b1eeaa43, Label0b56c0b3b7e8a4f, TextFieldNome, Label0ae494d40ed6f4b, CopyLabel0he4d96fd54264a, TextFieldParenteAbrigado, CopyLabel0eae5aa3bb11a4d, TextFieldTelefone, CopyLabel0j8d66f61efeb4e, TextFieldEmail);
            var PaddedButtonRound = new voltmx.ui.FlexContainer({
                "bottom": "0",
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "PaddedButtonRound",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox0e47154d54d4b41",
                "width": "90%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            PaddedButtonRound.setDefaultUnit(voltmx.flex.DP);
            var ButtonRound = new voltmx.ui.Button({
                "bottom": "10dp",
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "ButtonSkinActive",
                "height": "40dp",
                "id": "ButtonRound",
                "isVisible": true,
                "left": "25%",
                "onClick": controller.AS_Button_hf9869f14f1d4b18bce12aaba29e7aee,
                "right": "20dp",
                "skin": "ButtonSkinNormal",
                "text": "Enviar",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            PaddedButtonRound.add(ButtonRound);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "nav": {
                    "centerX": "50%",
                    "centerY": "",
                    "top": "0dp",
                    "width": "90%"
                }
            }
            this.add(nav, FlexContainer09, PaddedButtonRound);
        };
        return [{
            "addWidgets": addWidgetsfrmFinalizar,
            "enabledForIdleTimeout": false,
            "id": "frmFinalizar",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "Pesquisas"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});