define("Asilar/Acesso/userLogoutController", {
    //Type your controller code here 
});
define("Asilar/Acesso/LogoutControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Asilar/Acesso/LogoutController", ["Asilar/Acesso/userLogoutController", "Asilar/Acesso/LogoutControllerActions"], function() {
    var controller = require("Asilar/Acesso/userLogoutController");
    var controllerActions = ["Asilar/Acesso/LogoutControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
