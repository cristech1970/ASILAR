define("Asilar/Clientes/userfrmClientesCreateController", {
    //Type your controller code here 
});
define("Asilar/Clientes/frmClientesCreateControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_fa4045af81404e9d9a8058fc923815e9: function AS_Button_fa4045af81404e9d9a8058fc923815e9(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "Asilar",
            "friendlyName": "Clientes/frmClientesGrid"
        });
        ntf.navigate();
        kony.application.destroyForm('frmClientesCreate');
    },
    AS_Button_d2565d00a8224ad893e9cd7f908473eb: function AS_Button_d2565d00a8224ad893e9cd7f908473eb(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "Asilar",
            "friendlyName": "Clientes/frmClientesGrid"
        });
        ntf.navigate();
        kony.application.destroyForm('frmClientesCreate');
    },
    AS_Button_b0de3238289f4862a21e744a8342ce7e: function AS_Button_b0de3238289f4862a21e744a8342ce7e(eventobject) {
        var self = this;

        function SHOW_ALERT_be601747449d4a209bc9930e9a36e21d_True() {}

        function INVOKE_OBJECT_SERVICE_a4fa133f755c4dfabebf608dc6e1ea01_Callback(Clientes) {
            voltmx.application.dismissLoadingScreen();
            if (Clientes.opstatus == 0) {
                var ntf = new voltmx.mvc.Navigation({
                    "appName": "Asilar",
                    "friendlyName": "Clientes/frmClientesGrid"
                });
                ntf.navigate();
                kony.application.destroyForm('frmClientesCreate');
            } else {
                function SHOW_ALERT_be601747449d4a209bc9930e9a36e21d_Callback() {
                    SHOW_ALERT_be601747449d4a209bc9930e9a36e21d_True();
                }
                voltmx.ui.Alert({
                    "alertType": constants.ALERT_TYPE_INFO,
                    "alertTitle": null,
                    "yesLabel": null,
                    "noLabel": null,
                    "alertIcon": null,
                    "message": "Record creation failed! Please try again later.",
                    "alertHandler": SHOW_ALERT_be601747449d4a209bc9930e9a36e21d_Callback
                }, {
                    "iconPosition": constants.ALERT_ICON_POSITION_LEFT
                });
            }
        }
        voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        if (Clientes_inputparam == undefined) {
            var Clientes_inputparam = {};
        }
        Clientes_inputparam["serviceID"] = "AsilarBD$Clientes$create";
        Clientes_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "create"
        };
        var data = {};
        data["Id"] = voltmx.visualizer.toNumber(self.view.tbxId.text);
        data["InativoData"] = voltmx.visualizer.toISODateFormat(self.view.calInativoData.formattedDate);
        data["InativoMotivo"] = self.view.tbxInativoMotivo.text;
        data["ObitoDocumento"] = self.view.tbxObitoDocumento.text;
        data["InativoDetalhes"] = self.view.tbxInativoDetalhes.text;
        data["Nacionalidade"] = self.view.tbxNacionalidade.text;
        data["Naturalidade"] = self.view.tbxNaturalidade.text;
        data["Pai"] = self.view.tbxPai.text;
        data["Mae"] = self.view.tbxMae.text;
        data["Civil"] = self.view.tbxCivil.text;
        data["RG"] = self.view.tbxRG.text;
        data["CPF"] = self.view.tbxCPF.text;
        data["SUS"] = self.view.tbxSUS.text;
        data["TituloEleitor"] = self.view.tbxTituloEleitor.text;
        data["Interditado"] = self.view.tbxInterditado.text;
        data["InterditadoCurador"] = self.view.tbxInterditadoCurador.text;
        data["InterditadoData"] = voltmx.visualizer.toISODateFormat(self.view.calInterditadoData.formattedDate);
        data["InterditadoCuradorTelefone"] = self.view.tbxInterditadoCuradorTelefone.text;
        data["InterditadoCuradorEmail"] = self.view.tbxInterditadoCuradorEmail.text;
        data["ControleCaixaFlag"] = self.view.tbxControleCaixaFlag.text;
        data["EvangelicoFlag"] = self.view.tbxEvangelicoFlag.text;
        data["EvangelicoTipo"] = self.view.tbxEvangelicoTipo.text;
        data["EvangelicoSetor"] = self.view.tbxEvangelicoSetor.text;
        data["EvangelicoPastor"] = self.view.tbxEvangelicoPastor.text;
        data["EvangelicoMinisterio"] = self.view.tbxEvangelicoMinisterio.text;
        data["EvangelicoDenominacao"] = self.view.tbxEvangelicoDenominacao.text;
        data["EvangelicoAceiteJesusAsilar"] = self.view.tbxEvangelicoAceiteJesusAsilar.text;
        data["EvangelicoDetalhes"] = self.view.tbxEvangelicoDetalhes.text;
        data["MotivoAbrigamento"] = self.view.tbxMotivoAbrigamento.text;
        data["MotivoEscolha"] = self.view.tbxMotivoEscolha.text;
        Clientes_inputparam["options"]["data"] = data;
        var Clientes_httpheaders = {};
        Clientes_inputparam["httpheaders"] = Clientes_httpheaders;
        var Clientes_httpconfigs = {};
        Clientes_inputparam["httpconfig"] = Clientes_httpconfigs;
        AsilarBD$Clientes$create = mfobjectsecureinvokerasync(Clientes_inputparam, "AsilarBD", "Clientes", INVOKE_OBJECT_SERVICE_a4fa133f755c4dfabebf608dc6e1ea01_Callback);
    }
});
define("Asilar/Clientes/frmClientesCreateController", ["Asilar/Clientes/userfrmClientesCreateController", "Asilar/Clientes/frmClientesCreateControllerActions"], function() {
    var controller = require("Asilar/Clientes/userfrmClientesCreateController");
    var controllerActions = ["Asilar/Clientes/frmClientesCreateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
