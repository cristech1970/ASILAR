define("Asilar/navigation/NavigationController", {
    //Add your navigation controller code here.
});
