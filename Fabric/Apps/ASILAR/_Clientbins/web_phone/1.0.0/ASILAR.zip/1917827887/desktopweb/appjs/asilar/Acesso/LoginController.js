define("Asilar/Acesso/userLoginController", {
    //Type your controller code here 
});
define("Asilar/Acesso/LoginControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_f7b6890f2bc041a3bbffe0d26dbac27d: function AS_Button_f7b6890f2bc041a3bbffe0d26dbac27d(eventobject) {
        var self = this;

        function SHOW_ALERT_a8f84fa2a92e41cd904a6e44bb2817b8_True() {
            var ntf = new voltmx.mvc.Navigation({
                "appName": "Asilar",
                "friendlyName": "Acesso/MenuAcesso"
            });
            ntf.navigate();
        }

        function SHOW_ALERT_eae2dcb1024245b78ac0eca44b3c72b4_True() {}

        function INVOKE_IDENTITY_SERVICE_j9a96b74648b47fdbeb43978c947f6d7_Success(response) {
            voltmx.application.dismissLoadingScreen();

            function SHOW_ALERT_a8f84fa2a92e41cd904a6e44bb2817b8_Callback() {
                SHOW_ALERT_a8f84fa2a92e41cd904a6e44bb2817b8_True();
            }
            voltmx.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "You have successfully logged in.",
                "alertHandler": SHOW_ALERT_a8f84fa2a92e41cd904a6e44bb2817b8_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }

        function INVOKE_IDENTITY_SERVICE_j9a96b74648b47fdbeb43978c947f6d7_Failure(error) {
            voltmx.application.dismissLoadingScreen();

            function SHOW_ALERT_eae2dcb1024245b78ac0eca44b3c72b4_Callback() {
                SHOW_ALERT_eae2dcb1024245b78ac0eca44b3c72b4_True();
            }
            voltmx.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": null,
                "yesLabel": null,
                "noLabel": null,
                "alertIcon": null,
                "message": "Login failed. Please try again.",
                "alertHandler": SHOW_ALERT_eae2dcb1024245b78ac0eca44b3c72b4_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        if (login_inputparam == undefined) {
            var login_inputparam = {};
        }
        login_inputparam["serviceID"] = "AsilarLdap$login";
        login_inputparam["operation"] = "login";
        login_inputparam["userid"] = self.view.tbxuserid.text;
        login_inputparam["password"] = self.view.tbxpassword.text;
        AsilarLdap$login = mfidentityserviceinvoker("AsilarLdap", login_inputparam, INVOKE_IDENTITY_SERVICE_j9a96b74648b47fdbeb43978c947f6d7_Success, INVOKE_IDENTITY_SERVICE_j9a96b74648b47fdbeb43978c947f6d7_Failure);
    }
});
define("Asilar/Acesso/LoginController", ["Asilar/Acesso/userLoginController", "Asilar/Acesso/LoginControllerActions"], function() {
    var controller = require("Asilar/Acesso/userLoginController");
    var controllerActions = ["Asilar/Acesso/LoginControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
