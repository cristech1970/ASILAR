define("Asilar/Clientes/userfrmClientesUpdateController", {
    //Type your controller code here 
});
define("Asilar/Clientes/frmClientesUpdateControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_a34a9c4522c748f9b082b94caf46ef8b: function AS_Button_a34a9c4522c748f9b082b94caf46ef8b(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "Asilar",
            "friendlyName": "Clientes/frmClientesDetails"
        });
        ntf.navigate();
    },
    AS_Button_a26c9b5640174e3c8f35738077cc1edc: function AS_Button_a26c9b5640174e3c8f35738077cc1edc(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "Asilar",
            "friendlyName": "Clientes/frmClientesGrid"
        });
        ntf.navigate();
    },
    AS_Button_ca59cc4742e947baadddc4854e0f4a77: function AS_Button_ca59cc4742e947baadddc4854e0f4a77(eventobject) {
        var self = this;

        function SHOW_ALERT_c7d2e739e772421e9d775f6149502af6_True() {}

        function INVOKE_OBJECT_SERVICE_ef6970b224f743dd866444ff9baffe1d_Callback(Clientes) {
            voltmx.application.dismissLoadingScreen();
            if (Clientes.opstatus == 0) {
                var ntf = new voltmx.mvc.Navigation({
                    "appName": "Asilar",
                    "friendlyName": "Clientes/frmClientesDetails"
                });
                ntf.navigate({
                    "tbxId_text": self.view.tbxId.text,
                    "calInativoData_formattedDate": self.view.calInativoData.formattedDate,
                    "tbxInativoMotivo_text": self.view.tbxInativoMotivo.text,
                    "tbxObitoDocumento_text": self.view.tbxObitoDocumento.text,
                    "tbxInativoDetalhes_text": self.view.tbxInativoDetalhes.text,
                    "tbxNacionalidade_text": self.view.tbxNacionalidade.text,
                    "tbxNaturalidade_text": self.view.tbxNaturalidade.text,
                    "tbxPai_text": self.view.tbxPai.text,
                    "tbxMae_text": self.view.tbxMae.text,
                    "tbxCivil_text": self.view.tbxCivil.text,
                    "tbxRG_text": self.view.tbxRG.text,
                    "tbxCPF_text": self.view.tbxCPF.text,
                    "tbxSUS_text": self.view.tbxSUS.text,
                    "tbxTituloEleitor_text": self.view.tbxTituloEleitor.text,
                    "tbxInterditado_text": self.view.tbxInterditado.text,
                    "tbxInterditadoCurador_text": self.view.tbxInterditadoCurador.text,
                    "calInterditadoData_formattedDate": self.view.calInterditadoData.formattedDate,
                    "tbxInterditadoCuradorTelefone_text": self.view.tbxInterditadoCuradorTelefone.text,
                    "tbxInterditadoCuradorEmail_text": self.view.tbxInterditadoCuradorEmail.text,
                    "tbxControleCaixaFlag_text": self.view.tbxControleCaixaFlag.text,
                    "tbxEvangelicoFlag_text": self.view.tbxEvangelicoFlag.text,
                    "tbxEvangelicoTipo_text": self.view.tbxEvangelicoTipo.text,
                    "tbxEvangelicoSetor_text": self.view.tbxEvangelicoSetor.text,
                    "tbxEvangelicoPastor_text": self.view.tbxEvangelicoPastor.text,
                    "tbxEvangelicoMinisterio_text": self.view.tbxEvangelicoMinisterio.text,
                    "tbxEvangelicoDenominacao_text": self.view.tbxEvangelicoDenominacao.text,
                    "tbxEvangelicoAceiteJesusAsilar_text": self.view.tbxEvangelicoAceiteJesusAsilar.text,
                    "tbxEvangelicoDetalhes_text": self.view.tbxEvangelicoDetalhes.text,
                    "tbxMotivoAbrigamento_text": self.view.tbxMotivoAbrigamento.text,
                    "tbxMotivoEscolha_text": self.view.tbxMotivoEscolha.text,
                    "_meta_": {
                        "eventName": "onClick",
                        "widgetId": "btnSquared"
                    }
                });
            } else {
                function SHOW_ALERT_c7d2e739e772421e9d775f6149502af6_Callback() {
                    SHOW_ALERT_c7d2e739e772421e9d775f6149502af6_True();
                }
                voltmx.ui.Alert({
                    "alertType": constants.ALERT_TYPE_INFO,
                    "alertTitle": null,
                    "yesLabel": null,
                    "noLabel": null,
                    "alertIcon": null,
                    "message": "Record updation failed! Please try again later.",
                    "alertHandler": SHOW_ALERT_c7d2e739e772421e9d775f6149502af6_Callback
                }, {
                    "iconPosition": constants.ALERT_ICON_POSITION_LEFT
                });
            }
        }
        voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        if (Clientes_inputparam == undefined) {
            var Clientes_inputparam = {};
        }
        Clientes_inputparam["serviceID"] = "AsilarBD$Clientes$update";
        Clientes_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "update"
        };
        var data = {};
        data["Id"] = voltmx.visualizer.toNumber(self.view.tbxId.text);
        data["InativoData"] = voltmx.visualizer.toISODateFormat(self.view.calInativoData.formattedDate);
        data["InativoMotivo"] = self.view.tbxInativoMotivo.text;
        data["ObitoDocumento"] = self.view.tbxObitoDocumento.text;
        data["InativoDetalhes"] = self.view.tbxInativoDetalhes.text;
        data["Nacionalidade"] = self.view.tbxNacionalidade.text;
        data["Naturalidade"] = self.view.tbxNaturalidade.text;
        data["Pai"] = self.view.tbxPai.text;
        data["Mae"] = self.view.tbxMae.text;
        data["Civil"] = self.view.tbxCivil.text;
        data["RG"] = self.view.tbxRG.text;
        data["CPF"] = self.view.tbxCPF.text;
        data["SUS"] = self.view.tbxSUS.text;
        data["TituloEleitor"] = self.view.tbxTituloEleitor.text;
        data["Interditado"] = self.view.tbxInterditado.text;
        data["InterditadoCurador"] = self.view.tbxInterditadoCurador.text;
        data["InterditadoData"] = voltmx.visualizer.toISODateFormat(self.view.calInterditadoData.formattedDate);
        data["InterditadoCuradorTelefone"] = self.view.tbxInterditadoCuradorTelefone.text;
        data["InterditadoCuradorEmail"] = self.view.tbxInterditadoCuradorEmail.text;
        data["ControleCaixaFlag"] = self.view.tbxControleCaixaFlag.text;
        data["EvangelicoFlag"] = self.view.tbxEvangelicoFlag.text;
        data["EvangelicoTipo"] = self.view.tbxEvangelicoTipo.text;
        data["EvangelicoSetor"] = self.view.tbxEvangelicoSetor.text;
        data["EvangelicoPastor"] = self.view.tbxEvangelicoPastor.text;
        data["EvangelicoMinisterio"] = self.view.tbxEvangelicoMinisterio.text;
        data["EvangelicoDenominacao"] = self.view.tbxEvangelicoDenominacao.text;
        data["EvangelicoAceiteJesusAsilar"] = self.view.tbxEvangelicoAceiteJesusAsilar.text;
        data["EvangelicoDetalhes"] = self.view.tbxEvangelicoDetalhes.text;
        data["MotivoAbrigamento"] = self.view.tbxMotivoAbrigamento.text;
        data["MotivoEscolha"] = self.view.tbxMotivoEscolha.text;
        Clientes_inputparam["options"]["data"] = data;
        var Clientes_httpheaders = {};
        Clientes_inputparam["httpheaders"] = Clientes_httpheaders;
        var Clientes_httpconfigs = {};
        Clientes_inputparam["httpconfig"] = Clientes_httpconfigs;
        AsilarBD$Clientes$update = mfobjectsecureinvokerasync(Clientes_inputparam, "AsilarBD", "Clientes", INVOKE_OBJECT_SERVICE_ef6970b224f743dd866444ff9baffe1d_Callback);
    },
    AS_Form_f13338b4e5f34eb7804baf2956443b4b: function AS_Form_f13338b4e5f34eb7804baf2956443b4b(eventobject) {
        var self = this;

        function SHOW_ALERT_hc33e8d6bedc4d23b95d8be60edafa72_True() {}

        function INVOKE_OBJECT_SERVICE_j126e4e414ce4948b0ced618c556127b_Callback(Clientes) {
            voltmx.application.dismissLoadingScreen();
            if (Clientes.opstatus == 0) {
                self.view.tbxId.text = voltmx.visualizer.toString(Clientes["records"][0]["Id"]);
                self.view.calInativoData.dateComponents = voltmx.visualizer.toCalendarDateFormat(Clientes["records"][0]["InativoData"]).split('\/');
                self.view.tbxInativoMotivo.text = Clientes["records"][0]["InativoMotivo"];
                self.view.tbxObitoDocumento.text = Clientes["records"][0]["ObitoDocumento"];
                self.view.tbxInativoDetalhes.text = Clientes["records"][0]["InativoDetalhes"];
                self.view.tbxNacionalidade.text = Clientes["records"][0]["Nacionalidade"];
                self.view.tbxNaturalidade.text = Clientes["records"][0]["Naturalidade"];
                self.view.tbxPai.text = Clientes["records"][0]["Pai"];
                self.view.tbxMae.text = Clientes["records"][0]["Mae"];
                self.view.tbxCivil.text = Clientes["records"][0]["Civil"];
                self.view.tbxRG.text = Clientes["records"][0]["RG"];
                self.view.tbxCPF.text = Clientes["records"][0]["CPF"];
                self.view.tbxSUS.text = Clientes["records"][0]["SUS"];
                self.view.tbxTituloEleitor.text = Clientes["records"][0]["TituloEleitor"];
                self.view.tbxInterditado.text = Clientes["records"][0]["Interditado"];
                self.view.tbxInterditadoCurador.text = Clientes["records"][0]["InterditadoCurador"];
                self.view.calInterditadoData.dateComponents = voltmx.visualizer.toCalendarDateFormat(Clientes["records"][0]["InterditadoData"]).split('\/');
                self.view.tbxInterditadoCuradorTelefone.text = Clientes["records"][0]["InterditadoCuradorTelefone"];
                self.view.tbxInterditadoCuradorEmail.text = Clientes["records"][0]["InterditadoCuradorEmail"];
                self.view.tbxControleCaixaFlag.text = Clientes["records"][0]["ControleCaixaFlag"];
                self.view.tbxEvangelicoFlag.text = Clientes["records"][0]["EvangelicoFlag"];
                self.view.tbxEvangelicoTipo.text = Clientes["records"][0]["EvangelicoTipo"];
                self.view.tbxEvangelicoSetor.text = Clientes["records"][0]["EvangelicoSetor"];
                self.view.tbxEvangelicoPastor.text = Clientes["records"][0]["EvangelicoPastor"];
                self.view.tbxEvangelicoMinisterio.text = Clientes["records"][0]["EvangelicoMinisterio"];
                self.view.tbxEvangelicoDenominacao.text = Clientes["records"][0]["EvangelicoDenominacao"];
                self.view.tbxEvangelicoAceiteJesusAsilar.text = Clientes["records"][0]["EvangelicoAceiteJesusAsilar"];
                self.view.tbxEvangelicoDetalhes.text = Clientes["records"][0]["EvangelicoDetalhes"];
                self.view.tbxMotivoAbrigamento.text = Clientes["records"][0]["MotivoAbrigamento"];
                self.view.tbxMotivoEscolha.text = Clientes["records"][0]["MotivoEscolha"];
            } else {
                function SHOW_ALERT_hc33e8d6bedc4d23b95d8be60edafa72_Callback() {
                    SHOW_ALERT_hc33e8d6bedc4d23b95d8be60edafa72_True();
                }
                voltmx.ui.Alert({
                    "alertType": constants.ALERT_TYPE_INFO,
                    "alertTitle": null,
                    "yesLabel": null,
                    "noLabel": null,
                    "alertIcon": null,
                    "message": "Data Fetching failed! Please try again later.",
                    "alertHandler": SHOW_ALERT_hc33e8d6bedc4d23b95d8be60edafa72_Callback
                }, {
                    "iconPosition": constants.ALERT_ICON_POSITION_LEFT
                });
            }
        }
        if ((this.getPreviousForm() === "frmClientesDetails") && this.navigationContext && this.navigationContext._meta_ && (this.navigationContext._meta_.widgetId === "btnEdit") && (this.navigationContext._meta_.eventName === "onClick")) {
            voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
            if (Clientes_inputparam == undefined) {
                var Clientes_inputparam = {};
            }
            Clientes_inputparam["serviceID"] = "AsilarBD$Clientes$get";
            Clientes_inputparam["options"] = {
                "access": "online",
                "CRUD_TYPE": "get"
            };
            var odataParams = [];
            Clientes_inputparam["options"]["odataurl"] = odataParams.join("&");
            var Clientes_httpheaders = {};
            Clientes_inputparam["httpheaders"] = Clientes_httpheaders;
            var Clientes_httpconfigs = {};
            Clientes_inputparam["httpconfig"] = Clientes_httpconfigs;
            AsilarBD$Clientes$get = mfobjectsecureinvokerasync(Clientes_inputparam, "AsilarBD", "Clientes", INVOKE_OBJECT_SERVICE_j126e4e414ce4948b0ced618c556127b_Callback);
        }
    }
});
define("Asilar/Clientes/frmClientesUpdateController", ["Asilar/Clientes/userfrmClientesUpdateController", "Asilar/Clientes/frmClientesUpdateControllerActions"], function() {
    var controller = require("Asilar/Clientes/userfrmClientesUpdateController");
    var controllerActions = ["Asilar/Clientes/frmClientesUpdateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
