define("Pesquisas/AppGroup/userfrmQuestoesController", {
    //Type your controller code here 
});
define("Pesquisas/AppGroup/frmQuestoesControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_h935f78cffcb4e4790079747b9ae320f: function AS_Button_h935f78cffcb4e4790079747b9ae320f(eventobject) {
        var self = this;
        voltmx.application.showLoadingScreen(null, "Aguarde", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        var self = this;

        function SHOW_ALERT_ide_onClick_a1e3f34727e643f5a979d15750e68db6_True() {
            var ntf = new voltmx.mvc.Navigation("frmFinalizar");
            ntf.navigate();
        }

        function INVOKE_OBJECT_SERVICE_ide_onClick_fce9b7686cf14d13ab58558a5e6aac34_Callback(pesquisa) {
            voltmx.application.dismissLoadingScreen();

            function SHOW_ALERT_ide_onClick_a1e3f34727e643f5a979d15750e68db6_Callback() {
                SHOW_ALERT_ide_onClick_a1e3f34727e643f5a979d15750e68db6_True();
            }
            voltmx.ui.Alert({
                "alertType": constants.ALERT_TYPE_INFO,
                "alertTitle": "Pesquisas",
                "yesLabel": "Sim",
                "message": "Pesquisa salva, agora nos fale um pouco sobre você",
                "alertHandler": SHOW_ALERT_ide_onClick_a1e3f34727e643f5a979d15750e68db6_Callback
            }, {
                "iconPosition": constants.ALERT_ICON_POSITION_LEFT
            });
        }
        const hoje = new Date();
        dataAtual = hoje.toLocaleDateString();
        if (pesquisa_inputparam == undefined) {
            var pesquisa_inputparam = {};
        }
        pesquisa_inputparam["serviceID"] = "asilarDb$pesquisa$update";
        pesquisa_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "update"
        };
        var data = {};
        data["id"] = id;
        data["Desc01"] = self.view.TextArea01.text;
        data["Desc02"] = self.view.TextArea02.text;
        data["Desc03"] = self.view.TextArea03.text;
        data["Desc04"] = self.view.TextArea04.text;
        data["Desc05"] = self.view.TextArea05.text;
        data["Desc06"] = self.view.TextArea06.text;
        data["Desc07"] = self.view.TextArea07.text;
        data["Desc08"] = self.view.TextArea08.text;
        data["Resp01"] = self.view.ListBox01.selectedKey;
        data["Resp02"] = self.view.ListBox02.selectedKey;
        data["Resp03"] = self.view.ListBox03.selectedKey;
        data["Resp04"] = self.view.ListBox04.selectedKey;
        data["Resp05"] = self.view.ListBox05.selectedKey;
        data["Resp06"] = self.view.ListBox06.selectedKey;
        data["Resp07"] = self.view.ListBox07.selectedKey;
        pesquisa_inputparam["options"]["data"] = data;
        var pesquisa_httpheaders = {};
        pesquisa_inputparam["httpheaders"] = pesquisa_httpheaders;
        var pesquisa_httpconfigs = {};
        pesquisa_inputparam["httpconfig"] = pesquisa_httpconfigs;
        asilarDb$pesquisa$update = mfobjectsecureinvokerasync(pesquisa_inputparam, "asilarDb", "pesquisa", INVOKE_OBJECT_SERVICE_ide_onClick_fce9b7686cf14d13ab58558a5e6aac34_Callback);
    }
});
define("Pesquisas/AppGroup/frmQuestoesController", ["Pesquisas/AppGroup/userfrmQuestoesController", "Pesquisas/AppGroup/frmQuestoesControllerActions"], function() {
    var controller = require("Pesquisas/AppGroup/userfrmQuestoesController");
    var controllerActions = ["Pesquisas/AppGroup/frmQuestoesControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
