define("Pesquisas/AppGroup/frmQuestoes", function() {
    return function(controller) {
        function addWidgetsfrmQuestoes() {
            this.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0b72f160c74a743 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "FlexContainer0b72f160c74a743",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0b72f160c74a743.setDefaultUnit(voltmx.flex.DP);
            var nav = new asilar.nav({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "70dp",
                "id": "nav",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "Pesquisas",
                "overrides": {
                    "FlexContainer0db719fda9e144b": {
                        "centerX": "50%",
                        "width": "540dp"
                    },
                    "nav": {
                        "centerY": "viz.val_cleared",
                        "height": "70dp",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var FlexContainer01 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "320dp",
                "id": "FlexContainer01",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox1",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer01.setDefaultUnit(voltmx.flex.DP);
            var Label0fe959de51ea24a = new voltmx.ui.Label({
                "height": "60dp",
                "id": "Label0fe959de51ea24a",
                "isVisible": true,
                "left": "0%",
                "skin": "defLabel4",
                "text": "1 - Como classifica sua recepção ao chegar no LAR?",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var ListBox01 = new voltmx.ui.ListBox({
                "centerX": "50%",
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "ListBox01",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb0", "Selecione:"],
                    ["lb1", "Ótimo"],
                    ["lb2", "Bom"],
                    ["lb3", "Regular"],
                    ["lb4", "Ruim"],
                    ["lb5", "Péssimo"],
                    ["lb6", "Não sei responder"]
                ],
                "selectedKey": "lb0",
                "skin": "ListBox1",
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var Label0g5f11a43c3654d = new voltmx.ui.Label({
                "height": "40dp",
                "id": "Label0g5f11a43c3654d",
                "isVisible": true,
                "left": "2%",
                "skin": "defLabel2",
                "text": "Se possível, explique sua resposta:",
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextArea01 = new voltmx.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "120dp",
                "id": "TextArea01",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "numberOfVisibleLines": 3,
                "right": "0",
                "skin": "CopydefTextAreaNormal0e2a7cb1a613349",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            FlexContainer01.add(Label0fe959de51ea24a, ListBox01, Label0g5f11a43c3654d, TextArea01);
            var FlexContainer02 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "320dp",
                "id": "FlexContainer02",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox1",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer02.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0ceb9112f704347 = new voltmx.ui.Label({
                "height": "60dp",
                "id": "CopyLabel0ceb9112f704347",
                "isVisible": true,
                "left": "0%",
                "skin": "defLabel4",
                "text": "2 - Como encontrou seu parente abrigado?",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var ListBox02 = new voltmx.ui.ListBox({
                "centerX": "50%",
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "ListBox02",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb0", "Selecione:"],
                    ["lb1", "Ótimo"],
                    ["lb2", "Bom"],
                    ["lb3", "Regular"],
                    ["lb4", "Ruim"],
                    ["lb5", "Péssimo"],
                    ["lb6", "Não sei responder"]
                ],
                "selectedKey": "lb0",
                "skin": "ListBox1",
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var CopyLabel0g6bffa4cbae34e = new voltmx.ui.Label({
                "height": "40dp",
                "id": "CopyLabel0g6bffa4cbae34e",
                "isVisible": true,
                "left": "2%",
                "skin": "defLabel2",
                "text": "Se possível, explique sua resposta:",
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextArea02 = new voltmx.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "120dp",
                "id": "TextArea02",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "numberOfVisibleLines": 3,
                "right": "0",
                "skin": "CopydefTextAreaNormal0e2a7cb1a613349",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            FlexContainer02.add(CopyLabel0ceb9112f704347, ListBox02, CopyLabel0g6bffa4cbae34e, TextArea02);
            var FlexContainer03 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "320dp",
                "id": "FlexContainer03",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox1",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer03.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0a6a51e3dadf047 = new voltmx.ui.Label({
                "height": "60dp",
                "id": "CopyLabel0a6a51e3dadf047",
                "isVisible": true,
                "left": "0%",
                "skin": "defLabel4",
                "text": "3 - Como classifica o atendimento observado dos Cuidadores com os abrigados?",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var ListBox03 = new voltmx.ui.ListBox({
                "centerX": "50%",
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "ListBox03",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb0", "Selecione:"],
                    ["lb1", "Ótimo"],
                    ["lb2", "Bom"],
                    ["lb3", "Regular"],
                    ["lb4", "Ruim"],
                    ["lb5", "Péssimo"],
                    ["lb6", "Não sei responder"]
                ],
                "selectedKey": "lb0",
                "skin": "ListBox1",
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var CopyLabel0a8ff5b281fbe4c = new voltmx.ui.Label({
                "height": "40dp",
                "id": "CopyLabel0a8ff5b281fbe4c",
                "isVisible": true,
                "left": "2%",
                "skin": "defLabel2",
                "text": "Se possível, explique sua resposta:",
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextArea03 = new voltmx.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "120dp",
                "id": "TextArea03",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "numberOfVisibleLines": 3,
                "right": "0",
                "skin": "CopydefTextAreaNormal0e2a7cb1a613349",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            FlexContainer03.add(CopyLabel0a6a51e3dadf047, ListBox03, CopyLabel0a8ff5b281fbe4c, TextArea03);
            var FlexContainer04 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "320dp",
                "id": "FlexContainer04",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox1",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer04.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0g1cc6af8fa9145 = new voltmx.ui.Label({
                "height": "60dp",
                "id": "CopyLabel0g1cc6af8fa9145",
                "isVisible": true,
                "left": "0%",
                "skin": "defLabel4",
                "text": "4 - Como seu parente abrigado se refere ao atendimento dos Cuidadores?",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var ListBox04 = new voltmx.ui.ListBox({
                "centerX": "50%",
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "ListBox04",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb0", "Selecione:"],
                    ["lb1", "Ótimo"],
                    ["lb2", "Bom"],
                    ["lb3", "Regular"],
                    ["lb4", "Ruim"],
                    ["lb5", "Péssimo"],
                    ["lb6", "Não sei responder"]
                ],
                "selectedKey": "lb0",
                "skin": "ListBox1",
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var CopyLabel0e859c5b9e04544 = new voltmx.ui.Label({
                "height": "40dp",
                "id": "CopyLabel0e859c5b9e04544",
                "isVisible": true,
                "left": "2%",
                "skin": "defLabel2",
                "text": "Se possível, explique sua resposta:",
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextArea04 = new voltmx.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "120dp",
                "id": "TextArea04",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "numberOfVisibleLines": 3,
                "right": "0",
                "skin": "CopydefTextAreaNormal0e2a7cb1a613349",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            FlexContainer04.add(CopyLabel0g1cc6af8fa9145, ListBox04, CopyLabel0e859c5b9e04544, TextArea04);
            var FlexContainer05 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "320dp",
                "id": "FlexContainer05",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox1",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer05.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0e0fac0bf1ab74c = new voltmx.ui.Label({
                "height": "60dp",
                "id": "CopyLabel0e0fac0bf1ab74c",
                "isVisible": true,
                "left": "0%",
                "skin": "defLabel4",
                "text": "5 - Como seu parente abrigado se refere aos colegas abrigados?",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var ListBox05 = new voltmx.ui.ListBox({
                "centerX": "50%",
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "ListBox05",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb0", "Selecione:"],
                    ["lb1", "Ótimo"],
                    ["lb2", "Bom"],
                    ["lb3", "Regular"],
                    ["lb4", "Ruim"],
                    ["lb5", "Péssimo"],
                    ["lb6", "Não sei responder"]
                ],
                "selectedKey": "lb0",
                "skin": "ListBox1",
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var CopyLabel0ha7303bda59b49 = new voltmx.ui.Label({
                "height": "40dp",
                "id": "CopyLabel0ha7303bda59b49",
                "isVisible": true,
                "left": "2%",
                "skin": "defLabel2",
                "text": "Se possível, explique sua resposta:",
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextArea05 = new voltmx.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "120dp",
                "id": "TextArea05",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "numberOfVisibleLines": 3,
                "right": "0",
                "skin": "CopydefTextAreaNormal0e2a7cb1a613349",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            FlexContainer05.add(CopyLabel0e0fac0bf1ab74c, ListBox05, CopyLabel0ha7303bda59b49, TextArea05);
            var FlexContainer06 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "320dp",
                "id": "FlexContainer06",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox1",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer06.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0f93e923ccc0b48 = new voltmx.ui.Label({
                "height": "60dp",
                "id": "CopyLabel0f93e923ccc0b48",
                "isVisible": true,
                "left": "0%",
                "skin": "defLabel4",
                "text": "6 - Como classifica o estado das instalações do LAR?",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var ListBox06 = new voltmx.ui.ListBox({
                "centerX": "50%",
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "ListBox06",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb0", "Selecione:"],
                    ["lb1", "Ótimo"],
                    ["lb2", "Bom"],
                    ["lb3", "Regular"],
                    ["lb4", "Ruim"],
                    ["lb5", "Péssimo"],
                    ["lb6", "Não sei responder"]
                ],
                "selectedKey": "lb0",
                "skin": "ListBox1",
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var CopyLabel0a54a383c06834b = new voltmx.ui.Label({
                "height": "40dp",
                "id": "CopyLabel0a54a383c06834b",
                "isVisible": true,
                "left": "2%",
                "skin": "defLabel2",
                "text": "Se possível, explique sua resposta:",
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextArea06 = new voltmx.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "120dp",
                "id": "TextArea06",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "numberOfVisibleLines": 3,
                "right": "0",
                "skin": "CopydefTextAreaNormal0e2a7cb1a613349",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            FlexContainer06.add(CopyLabel0f93e923ccc0b48, ListBox06, CopyLabel0a54a383c06834b, TextArea06);
            var FlexContainer07 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "320dp",
                "id": "FlexContainer07",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox1",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer07.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0c9662d41e5e640 = new voltmx.ui.Label({
                "height": "60dp",
                "id": "CopyLabel0c9662d41e5e640",
                "isVisible": true,
                "left": "0%",
                "skin": "defLabel4",
                "text": "7 – Como classifica o estado dos móveis e utensílios existentes no LAR ?",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var ListBox07 = new voltmx.ui.ListBox({
                "centerX": "50%",
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "ListBox07",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb0", "Selecione:"],
                    ["lb1", "Ótimo"],
                    ["lb2", "Bom"],
                    ["lb3", "Regular"],
                    ["lb4", "Ruim"],
                    ["lb5", "Péssimo"],
                    ["lb6", "Não sei responder"]
                ],
                "selectedKey": "lb0",
                "skin": "ListBox1",
                "top": "10dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var CopyLabel0g463a40f185546 = new voltmx.ui.Label({
                "height": "40dp",
                "id": "CopyLabel0g463a40f185546",
                "isVisible": true,
                "left": "2%",
                "skin": "defLabel2",
                "text": "Se possível, explique sua resposta:",
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextArea07 = new voltmx.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "120dp",
                "id": "TextArea07",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "numberOfVisibleLines": 3,
                "right": "0",
                "skin": "CopydefTextAreaNormal0e2a7cb1a613349",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            FlexContainer07.add(CopyLabel0c9662d41e5e640, ListBox07, CopyLabel0g463a40f185546, TextArea07);
            var FlexContainer08 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "300dp",
                "id": "FlexContainer08",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox1",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer08.setDefaultUnit(voltmx.flex.DP);
            var CopyLabel0c8957570d03048 = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "CopyLabel0c8957570d03048",
                "isVisible": true,
                "left": "0%",
                "skin": "defLabel4",
                "text": "8 – Deixe livremente sua opinião/sugestão sobre qualquer assunto que queira a respeito do atendimento prestado pelo ASILAR.",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var TextArea08 = new voltmx.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "210dp",
                "id": "TextArea08",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "numberOfVisibleLines": 3,
                "right": "0",
                "skin": "CopydefTextAreaNormal0e2a7cb1a613349",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            FlexContainer08.add(CopyLabel0c8957570d03048, TextArea08);
            var PaddedButtonRound = new voltmx.ui.FlexContainer({
                "bottom": "50dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "PaddedButtonRound",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox0e47154d54d4b41",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            PaddedButtonRound.setDefaultUnit(voltmx.flex.DP);
            var Button02 = new voltmx.ui.Button({
                "bottom": "10dp",
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "ButtonSkinActive",
                "height": "40dp",
                "id": "Button02",
                "isVisible": true,
                "left": "25%",
                "onClick": controller.AS_Button_h935f78cffcb4e4790079747b9ae320f,
                "right": "20dp",
                "skin": "ButtonSkinNormal",
                "text": "Próximo",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            PaddedButtonRound.add(Button02);
            FlexContainer0b72f160c74a743.add(nav, FlexContainer01, FlexContainer02, FlexContainer03, FlexContainer04, FlexContainer05, FlexContainer06, FlexContainer07, FlexContainer08, PaddedButtonRound);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "nav.FlexContainer0db719fda9e144b": {
                    "centerX": "50%",
                    "width": "540dp"
                },
                "nav": {
                    "centerY": "",
                    "height": "70dp",
                    "top": "0dp"
                }
            }
            this.add(FlexContainer0b72f160c74a743);
        };
        return [{
            "addWidgets": addWidgetsfrmQuestoes,
            "enabledForIdleTimeout": false,
            "id": "frmQuestoes",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "Pesquisas"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});