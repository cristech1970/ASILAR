define("Asilar/Acesso/userMenuAcessoController", {
    //Type your controller code here 
});
define("Asilar/Acesso/MenuAcessoControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_c7ed56f2de584c92ae56c2f14fae0bc2: function AS_FlexContainer_c7ed56f2de584c92ae56c2f14fae0bc2(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "Asilar",
            "friendlyName": "Clientes/frmClientesGrid"
        });
        ntf.navigate();
    }
});
define("Asilar/Acesso/MenuAcessoController", ["Asilar/Acesso/userMenuAcessoController", "Asilar/Acesso/MenuAcessoControllerActions"], function() {
    var controller = require("Asilar/Acesso/userMenuAcessoController");
    var controllerActions = ["Asilar/Acesso/MenuAcessoControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
