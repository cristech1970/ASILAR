define("Asilar/Clientes/userfrmClientesDetailsController", {
    //Type your controller code here 
});
define("Asilar/Clientes/frmClientesDetailsControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_i625e3fea9964beca6fe57a4a2416378: function AS_Button_i625e3fea9964beca6fe57a4a2416378(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "Asilar",
            "friendlyName": "Clientes/frmClientesGrid"
        });
        ntf.navigate();
    },
    AS_Button_jd3bc5d9dbb442328d0cf8fe39166fef: function AS_Button_jd3bc5d9dbb442328d0cf8fe39166fef(eventobject) {
        var self = this;

        function SHOW_ALERT_cdb5400daf114a88bc7fd86ae8c460a2_True() {}

        function INVOKE_OBJECT_SERVICE_ee743d12a11c403fadcd4ffbbafde394_Callback(Clientes) {
            voltmx.application.dismissLoadingScreen();
            if (Clientes.opstatus == 0) {
                var ntf = new voltmx.mvc.Navigation({
                    "appName": "Asilar",
                    "friendlyName": "Clientes/frmClientesGrid"
                });
                ntf.navigate();
            } else {
                function SHOW_ALERT_cdb5400daf114a88bc7fd86ae8c460a2_Callback() {
                    SHOW_ALERT_cdb5400daf114a88bc7fd86ae8c460a2_True();
                }
                voltmx.ui.Alert({
                    "alertType": constants.ALERT_TYPE_INFO,
                    "alertTitle": null,
                    "yesLabel": null,
                    "noLabel": null,
                    "alertIcon": null,
                    "message": "Record deletion failed! Please try again later.",
                    "alertHandler": SHOW_ALERT_cdb5400daf114a88bc7fd86ae8c460a2_Callback
                }, {
                    "iconPosition": constants.ALERT_ICON_POSITION_LEFT
                });
            }
        }
        voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
        if (Clientes_inputparam == undefined) {
            var Clientes_inputparam = {};
        }
        Clientes_inputparam["serviceID"] = "AsilarBD$Clientes$delete";
        Clientes_inputparam["options"] = {
            "access": "online",
            "CRUD_TYPE": "delete"
        };
        var data = {};
        data["Id"] = voltmx.visualizer.toNumber(self.view.lblIdValue.text);
        Clientes_inputparam["options"]["data"] = data;
        var Clientes_httpheaders = {};
        Clientes_inputparam["httpheaders"] = Clientes_httpheaders;
        var Clientes_httpconfigs = {};
        Clientes_inputparam["httpconfig"] = Clientes_httpconfigs;
        AsilarBD$Clientes$delete = mfobjectsecureinvokerasync(Clientes_inputparam, "AsilarBD", "Clientes", INVOKE_OBJECT_SERVICE_ee743d12a11c403fadcd4ffbbafde394_Callback);
    },
    AS_Button_i479b7fc861748868992508d3d1488bf: function AS_Button_i479b7fc861748868992508d3d1488bf(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "Asilar",
            "friendlyName": "Clientes/frmClientesUpdate"
        });
        ntf.navigate({
            "lblIdValue_text": self.view.lblIdValue.text,
            "lblInativoDataValue_text": self.view.lblInativoDataValue.text,
            "lblInativoMotivoValue_text": self.view.lblInativoMotivoValue.text,
            "lblObitoDocumentoValue_text": self.view.lblObitoDocumentoValue.text,
            "lblInativoDetalhesValue_text": self.view.lblInativoDetalhesValue.text,
            "lblNacionalidadeValue_text": self.view.lblNacionalidadeValue.text,
            "lblNaturalidadeValue_text": self.view.lblNaturalidadeValue.text,
            "lblPaiValue_text": self.view.lblPaiValue.text,
            "lblMaeValue_text": self.view.lblMaeValue.text,
            "lblCivilValue_text": self.view.lblCivilValue.text,
            "lblRGValue_text": self.view.lblRGValue.text,
            "lblCPFValue_text": self.view.lblCPFValue.text,
            "lblSUSValue_text": self.view.lblSUSValue.text,
            "lblTituloEleitorValue_text": self.view.lblTituloEleitorValue.text,
            "lblInterditadoValue_text": self.view.lblInterditadoValue.text,
            "lblInterditadoCuradorValue_text": self.view.lblInterditadoCuradorValue.text,
            "lblInterditadoDataValue_text": self.view.lblInterditadoDataValue.text,
            "lblInterditadoCuradorTelefoneValue_text": self.view.lblInterditadoCuradorTelefoneValue.text,
            "lblInterditadoCuradorEmailValue_text": self.view.lblInterditadoCuradorEmailValue.text,
            "lblControleCaixaFlagValue_text": self.view.lblControleCaixaFlagValue.text,
            "lblEvangelicoFlagValue_text": self.view.lblEvangelicoFlagValue.text,
            "lblEvangelicoTipoValue_text": self.view.lblEvangelicoTipoValue.text,
            "lblEvangelicoSetorValue_text": self.view.lblEvangelicoSetorValue.text,
            "lblEvangelicoPastorValue_text": self.view.lblEvangelicoPastorValue.text,
            "lblEvangelicoMinisterioValue_text": self.view.lblEvangelicoMinisterioValue.text,
            "lblEvangelicoDenominacaoValue_text": self.view.lblEvangelicoDenominacaoValue.text,
            "lblEvangelicoAceiteJesusAsilarValue_text": self.view.lblEvangelicoAceiteJesusAsilarValue.text,
            "lblEvangelicoDetalhesValue_text": self.view.lblEvangelicoDetalhesValue.text,
            "lblMotivoAbrigamentoValue_text": self.view.lblMotivoAbrigamentoValue.text,
            "lblMotivoEscolhaValue_text": self.view.lblMotivoEscolhaValue.text,
            "_meta_": {
                "eventName": "onClick",
                "widgetId": "btnEdit"
            }
        });
    },
    AS_Form_d7b679cb31b642ec8ebd7ba8967e1a6f: function AS_Form_d7b679cb31b642ec8ebd7ba8967e1a6f(eventobject) {
        var self = this;

        function SHOW_ALERT_a2255d28d508468681a127fc2752d34b_True() {}

        function SHOW_ALERT_f105852d47ae436d8432d8e8a51134f2_True() {}

        function INVOKE_OBJECT_SERVICE_adaf0ad5837448eab0746cb0ac31520c_Callback(Clientes) {
            voltmx.application.dismissLoadingScreen();
            if (Clientes.opstatus == 0) {
                self.view.lblIdValue.text = voltmx.visualizer.toString(Clientes["records"][0]["Id"]);
                self.view.lblInativoDataValue.text = voltmx.visualizer.toCalendarDateFormat(Clientes["records"][0]["InativoData"]);
                self.view.lblInativoMotivoValue.text = Clientes["records"][0]["InativoMotivo"];
                self.view.lblObitoDocumentoValue.text = Clientes["records"][0]["ObitoDocumento"];
                self.view.lblInativoDetalhesValue.text = Clientes["records"][0]["InativoDetalhes"];
                self.view.lblNacionalidadeValue.text = Clientes["records"][0]["Nacionalidade"];
                self.view.lblNaturalidadeValue.text = Clientes["records"][0]["Naturalidade"];
                self.view.lblPaiValue.text = Clientes["records"][0]["Pai"];
                self.view.lblMaeValue.text = Clientes["records"][0]["Mae"];
                self.view.lblCivilValue.text = Clientes["records"][0]["Civil"];
                self.view.lblRGValue.text = Clientes["records"][0]["RG"];
                self.view.lblCPFValue.text = Clientes["records"][0]["CPF"];
                self.view.lblSUSValue.text = Clientes["records"][0]["SUS"];
                self.view.lblTituloEleitorValue.text = Clientes["records"][0]["TituloEleitor"];
                self.view.lblInterditadoValue.text = Clientes["records"][0]["Interditado"];
                self.view.lblInterditadoCuradorValue.text = Clientes["records"][0]["InterditadoCurador"];
                self.view.lblInterditadoDataValue.text = voltmx.visualizer.toCalendarDateFormat(Clientes["records"][0]["InterditadoData"]);
                self.view.lblInterditadoCuradorTelefoneValue.text = Clientes["records"][0]["InterditadoCuradorTelefone"];
                self.view.lblInterditadoCuradorEmailValue.text = Clientes["records"][0]["InterditadoCuradorEmail"];
                self.view.lblControleCaixaFlagValue.text = Clientes["records"][0]["ControleCaixaFlag"];
                self.view.lblEvangelicoFlagValue.text = Clientes["records"][0]["EvangelicoFlag"];
                self.view.lblEvangelicoTipoValue.text = Clientes["records"][0]["EvangelicoTipo"];
                self.view.lblEvangelicoSetorValue.text = Clientes["records"][0]["EvangelicoSetor"];
                self.view.lblEvangelicoPastorValue.text = Clientes["records"][0]["EvangelicoPastor"];
                self.view.lblEvangelicoMinisterioValue.text = Clientes["records"][0]["EvangelicoMinisterio"];
                self.view.lblEvangelicoDenominacaoValue.text = Clientes["records"][0]["EvangelicoDenominacao"];
                self.view.lblEvangelicoAceiteJesusAsilarValue.text = Clientes["records"][0]["EvangelicoAceiteJesusAsilar"];
                self.view.lblEvangelicoDetalhesValue.text = Clientes["records"][0]["EvangelicoDetalhes"];
                self.view.lblMotivoAbrigamentoValue.text = Clientes["records"][0]["MotivoAbrigamento"];
                self.view.lblMotivoEscolhaValue.text = Clientes["records"][0]["MotivoEscolha"];
            } else {
                function SHOW_ALERT_a2255d28d508468681a127fc2752d34b_Callback() {
                    SHOW_ALERT_a2255d28d508468681a127fc2752d34b_True();
                }
                voltmx.ui.Alert({
                    "alertType": constants.ALERT_TYPE_INFO,
                    "alertTitle": null,
                    "yesLabel": null,
                    "noLabel": null,
                    "alertIcon": null,
                    "message": "Data fetching failed! Please try again later.",
                    "alertHandler": SHOW_ALERT_a2255d28d508468681a127fc2752d34b_Callback
                }, {
                    "iconPosition": constants.ALERT_ICON_POSITION_LEFT
                });
            }
        }

        function INVOKE_OBJECT_SERVICE_b44ab52534574e468be9e8d5aaaae9d6_Callback(Clientes) {
            voltmx.application.dismissLoadingScreen();
            if (Clientes.opstatus == 0) {
                self.view.lblIdValue.text = voltmx.visualizer.toString(Clientes["records"][0]["Id"]);
                self.view.lblInativoDataValue.text = voltmx.visualizer.toCalendarDateFormat(Clientes["records"][0]["InativoData"]);
                self.view.lblInativoMotivoValue.text = Clientes["records"][0]["InativoMotivo"];
                self.view.lblObitoDocumentoValue.text = Clientes["records"][0]["ObitoDocumento"];
                self.view.lblInativoDetalhesValue.text = Clientes["records"][0]["InativoDetalhes"];
                self.view.lblNacionalidadeValue.text = Clientes["records"][0]["Nacionalidade"];
                self.view.lblNaturalidadeValue.text = Clientes["records"][0]["Naturalidade"];
                self.view.lblPaiValue.text = Clientes["records"][0]["Pai"];
                self.view.lblMaeValue.text = Clientes["records"][0]["Mae"];
                self.view.lblCivilValue.text = Clientes["records"][0]["Civil"];
                self.view.lblRGValue.text = Clientes["records"][0]["RG"];
                self.view.lblCPFValue.text = Clientes["records"][0]["CPF"];
                self.view.lblSUSValue.text = Clientes["records"][0]["SUS"];
                self.view.lblTituloEleitorValue.text = Clientes["records"][0]["TituloEleitor"];
                self.view.lblInterditadoValue.text = Clientes["records"][0]["Interditado"];
                self.view.lblInterditadoCuradorValue.text = Clientes["records"][0]["InterditadoCurador"];
                self.view.lblInterditadoDataValue.text = voltmx.visualizer.toCalendarDateFormat(Clientes["records"][0]["InterditadoData"]);
                self.view.lblInterditadoCuradorTelefoneValue.text = Clientes["records"][0]["InterditadoCuradorTelefone"];
                self.view.lblInterditadoCuradorEmailValue.text = Clientes["records"][0]["InterditadoCuradorEmail"];
                self.view.lblControleCaixaFlagValue.text = Clientes["records"][0]["ControleCaixaFlag"];
                self.view.lblEvangelicoFlagValue.text = Clientes["records"][0]["EvangelicoFlag"];
                self.view.lblEvangelicoTipoValue.text = Clientes["records"][0]["EvangelicoTipo"];
                self.view.lblEvangelicoSetorValue.text = Clientes["records"][0]["EvangelicoSetor"];
                self.view.lblEvangelicoPastorValue.text = Clientes["records"][0]["EvangelicoPastor"];
                self.view.lblEvangelicoMinisterioValue.text = Clientes["records"][0]["EvangelicoMinisterio"];
                self.view.lblEvangelicoDenominacaoValue.text = Clientes["records"][0]["EvangelicoDenominacao"];
                self.view.lblEvangelicoAceiteJesusAsilarValue.text = Clientes["records"][0]["EvangelicoAceiteJesusAsilar"];
                self.view.lblEvangelicoDetalhesValue.text = Clientes["records"][0]["EvangelicoDetalhes"];
                self.view.lblMotivoAbrigamentoValue.text = Clientes["records"][0]["MotivoAbrigamento"];
                self.view.lblMotivoEscolhaValue.text = Clientes["records"][0]["MotivoEscolha"];
            } else {
                function SHOW_ALERT_f105852d47ae436d8432d8e8a51134f2_Callback() {
                    SHOW_ALERT_f105852d47ae436d8432d8e8a51134f2_True();
                }
                voltmx.ui.Alert({
                    "alertType": constants.ALERT_TYPE_INFO,
                    "alertTitle": null,
                    "yesLabel": null,
                    "noLabel": null,
                    "alertIcon": null,
                    "message": "Data fetch failed! Please try again later.",
                    "alertHandler": SHOW_ALERT_f105852d47ae436d8432d8e8a51134f2_Callback
                }, {
                    "iconPosition": constants.ALERT_ICON_POSITION_LEFT
                });
            }
        }
        if ((this.getPreviousForm() === "frmClientesGrid") && this.navigationContext && this.navigationContext._meta_ && (this.navigationContext._meta_.widgetId === "segClientes") && (this.navigationContext._meta_.eventName === "onRowClick")) {
            voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
            if (Clientes_inputparam == undefined) {
                var Clientes_inputparam = {};
            }
            Clientes_inputparam["serviceID"] = "AsilarBD$Clientes$get";
            Clientes_inputparam["options"] = {
                "access": "online",
                "CRUD_TYPE": "get"
            };
            var odataParams = [];
            var filters = [];
            filters.push("Id eq '" + voltmx.visualizer.toNumber(this.navigationContext.segClientes_lblId1) + "' and InativoData eq '" + voltmx.visualizer.toISODateFormat(this.navigationContext.segClientes_lblInativoData1) + "' and InativoMotivo eq '" + this.navigationContext.segClientes_lblInativoMotivo1 + "' and ObitoDocumento eq '" + this.navigationContext.segClientes_lblObitoDocumento1 + "' and InativoDetalhes eq '" + this.navigationContext.segClientes_lblInativoDetalhes1 + "' and Nacionalidade eq '" + this.navigationContext.segClientes_lblNacionalidade1 + "' and Naturalidade eq '" + this.navigationContext.segClientes_lblNaturalidade1 + "' and Pai eq '" + this.navigationContext.segClientes_lblPai1 + "' and Mae eq '" + this.navigationContext.segClientes_lblMae1 + "' and Civil eq '" + this.navigationContext.segClientes_lblCivil1 + "' and RG eq '" + this.navigationContext.segClientes_lblRG1 + "' and CPF eq '" + this.navigationContext.segClientes_lblCPF1 + "' and SUS eq '" + this.navigationContext.segClientes_lblSUS1 + "' and TituloEleitor eq '" + this.navigationContext.segClientes_lblTituloEleitor1 + "' and Interditado eq '" + this.navigationContext.segClientes_lblInterditado1 + "' and InterditadoCurador eq '" + this.navigationContext.segClientes_lblInterditadoCurador1 + "' and InterditadoData eq '" + voltmx.visualizer.toISODateFormat(this.navigationContext.segClientes_lblInterditadoData1) + "' and InterditadoCuradorTelefone eq '" + this.navigationContext.segClientes_lblInterditadoCuradorTelefone1 + "' and InterditadoCuradorEmail eq '" + this.navigationContext.segClientes_lblInterditadoCuradorEmail1 + "' and ControleCaixaFlag eq '" + this.navigationContext.segClientes_lblControleCaixaFlag1 + "' and EvangelicoFlag eq '" + this.navigationContext.segClientes_lblEvangelicoFlag1 + "' and EvangelicoTipo eq '" + this.navigationContext.segClientes_lblEvangelicoTipo1 + "' and EvangelicoSetor eq '" + this.navigationContext.segClientes_lblEvangelicoSetor1 + "' and EvangelicoPastor eq '" + this.navigationContext.segClientes_lblEvangelicoPastor1 + "' and EvangelicoMinisterio eq '" + this.navigationContext.segClientes_lblEvangelicoMinisterio1 + "' and EvangelicoDenominacao eq '" + this.navigationContext.segClientes_lblEvangelicoDenominacao1 + "' and EvangelicoAceiteJesusAsilar eq '" + this.navigationContext.segClientes_lblEvangelicoAceiteJesusAsilar1 + "' and EvangelicoDetalhes eq '" + this.navigationContext.segClientes_lblEvangelicoDetalhes1 + "' and MotivoAbrigamento eq '" + this.navigationContext.segClientes_lblMotivoAbrigamento1 + "' and MotivoEscolha eq '" + this.navigationContext.segClientes_lblMotivoEscolha1 + "'");
            odataParams.push("$filter=" + filters.join(' and '));
            Clientes_inputparam["options"]["odataurl"] = odataParams.join("&");
            var Clientes_httpheaders = {};
            Clientes_inputparam["httpheaders"] = Clientes_httpheaders;
            var Clientes_httpconfigs = {};
            Clientes_inputparam["httpconfig"] = Clientes_httpconfigs;
            AsilarBD$Clientes$get = mfobjectsecureinvokerasync(Clientes_inputparam, "AsilarBD", "Clientes", INVOKE_OBJECT_SERVICE_b44ab52534574e468be9e8d5aaaae9d6_Callback);
        }
        if ((this.getPreviousForm() === "frmClientesUpdate") && this.navigationContext && this.navigationContext._meta_ && (this.navigationContext._meta_.widgetId === "btnSquared") && (this.navigationContext._meta_.eventName === "onClick")) {
            voltmx.application.showLoadingScreen(null, null, constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {});
            if (Clientes_inputparam == undefined) {
                var Clientes_inputparam = {};
            }
            Clientes_inputparam["serviceID"] = "AsilarBD$Clientes$get";
            Clientes_inputparam["options"] = {
                "access": "online",
                "CRUD_TYPE": "get"
            };
            var odataParams = [];
            var filters = [];
            filters.push("Id eq '" + voltmx.visualizer.toNumber(this.navigationContext.tbxId_text) + "' and InativoData eq '" + voltmx.visualizer.toISODateFormat(this.navigationContext.calInativoData_formattedDate) + "' and InativoMotivo eq '" + this.navigationContext.tbxInativoMotivo_text + "' and ObitoDocumento eq '" + this.navigationContext.tbxObitoDocumento_text + "' and InativoDetalhes eq '" + this.navigationContext.tbxInativoDetalhes_text + "' and Nacionalidade eq '" + this.navigationContext.tbxNacionalidade_text + "' and Naturalidade eq '" + this.navigationContext.tbxNaturalidade_text + "' and Pai eq '" + this.navigationContext.tbxPai_text + "' and Mae eq '" + this.navigationContext.tbxMae_text + "' and Civil eq '" + this.navigationContext.tbxCivil_text + "' and RG eq '" + this.navigationContext.tbxRG_text + "' and CPF eq '" + this.navigationContext.tbxCPF_text + "' and SUS eq '" + this.navigationContext.tbxSUS_text + "' and TituloEleitor eq '" + this.navigationContext.tbxTituloEleitor_text + "' and Interditado eq '" + this.navigationContext.tbxInterditado_text + "' and InterditadoCurador eq '" + this.navigationContext.tbxInterditadoCurador_text + "' and InterditadoData eq '" + voltmx.visualizer.toISODateFormat(this.navigationContext.calInterditadoData_formattedDate) + "' and InterditadoCuradorTelefone eq '" + this.navigationContext.tbxInterditadoCuradorTelefone_text + "' and InterditadoCuradorEmail eq '" + this.navigationContext.tbxInterditadoCuradorEmail_text + "' and ControleCaixaFlag eq '" + this.navigationContext.tbxControleCaixaFlag_text + "' and EvangelicoFlag eq '" + this.navigationContext.tbxEvangelicoFlag_text + "' and EvangelicoTipo eq '" + this.navigationContext.tbxEvangelicoTipo_text + "' and EvangelicoSetor eq '" + this.navigationContext.tbxEvangelicoSetor_text + "' and EvangelicoPastor eq '" + this.navigationContext.tbxEvangelicoPastor_text + "' and EvangelicoMinisterio eq '" + this.navigationContext.tbxEvangelicoMinisterio_text + "' and EvangelicoDenominacao eq '" + this.navigationContext.tbxEvangelicoDenominacao_text + "' and EvangelicoAceiteJesusAsilar eq '" + this.navigationContext.tbxEvangelicoAceiteJesusAsilar_text + "' and EvangelicoDetalhes eq '" + this.navigationContext.tbxEvangelicoDetalhes_text + "' and MotivoAbrigamento eq '" + this.navigationContext.tbxMotivoAbrigamento_text + "' and MotivoEscolha eq '" + this.navigationContext.tbxMotivoEscolha_text + "'");
            odataParams.push("$filter=" + filters.join(' and '));
            Clientes_inputparam["options"]["odataurl"] = odataParams.join("&");
            var Clientes_httpheaders = {};
            Clientes_inputparam["httpheaders"] = Clientes_httpheaders;
            var Clientes_httpconfigs = {};
            Clientes_inputparam["httpconfig"] = Clientes_httpconfigs;
            AsilarBD$Clientes$get = mfobjectsecureinvokerasync(Clientes_inputparam, "AsilarBD", "Clientes", INVOKE_OBJECT_SERVICE_adaf0ad5837448eab0746cb0ac31520c_Callback);
        }
    }
});
define("Asilar/Clientes/frmClientesDetailsController", ["Asilar/Clientes/userfrmClientesDetailsController", "Asilar/Clientes/frmClientesDetailsControllerActions"], function() {
    var controller = require("Asilar/Clientes/userfrmClientesDetailsController");
    var controllerActions = ["Asilar/Clientes/frmClientesDetailsControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
