define("Pesquisas/AppGroup/frmStart", function() {
    return function(controller) {
        function addWidgetsfrmStart() {
            this.setDefaultUnit(voltmx.flex.DP);
            var nav = new asilar.nav({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "70dp",
                "id": "nav",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "Pesquisas",
                "overrides": {
                    "FlexContainer0ab0fc83d79d44f": {
                        "centerX": "viz.val_cleared",
                        "left": 70,
                        "right": "0dp"
                    },
                    "FlexContainer0db719fda9e144b": {
                        "layoutType": voltmx.flex.FREE_FORM
                    },
                    "FlexContainer0h13fb7371bfe48": {
                        "centerX": "viz.val_cleared",
                        "left": "0dp"
                    },
                    "Image0e45ade2c62da44": {
                        "centerX": "viz.val_cleared",
                        "left": "0dp"
                    },
                    "nav": {
                        "centerX": "50%",
                        "height": "70dp",
                        "width": "90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var FlexContainer0fd6dfe80fafe4a = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "60%",
                "id": "FlexContainer0fd6dfe80fafe4a",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "CopyslFbox0f30382b592424d",
                "top": 595,
                "width": "90%",
                "zIndex": 1,
                "appName": "Pesquisas"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0fd6dfe80fafe4a.setDefaultUnit(voltmx.flex.DP);
            var RichText0i2986006fe8f4d = new voltmx.ui.RichText({
                "centerX": "50%",
                "id": "RichText0i2986006fe8f4d",
                "isVisible": true,
                "left": "16dp",
                "linkSkin": "defRichTextLink",
                "skin": "RichTextNormalArial100Bold",
                "text": "PESQUISA ENTRE OS FAMILIARES QUE VISITAM SEUS PARENTES ACOLHIDOS NO ASILAR, LAR REDENÇÃO, EM DESCALVADO. ",
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichText0c6a1c71b24cb44 = new voltmx.ui.RichText({
                "centerX": "50%",
                "id": "RichText0c6a1c71b24cb44",
                "isVisible": true,
                "left": "16dp",
                "linkSkin": "defRichTextLink",
                "skin": "RichTextNormalArial100",
                "text": "A Direção do ASILAR faz um esforço constante para melhorar o nível de qualidade de vida de seus acolhidos.",
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichText0bac21d7eabb64e = new voltmx.ui.RichText({
                "centerX": "50%",
                "id": "RichText0bac21d7eabb64e",
                "isVisible": true,
                "left": "16dp",
                "linkSkin": "defRichTextLink",
                "skin": "RichTextNormalArial100",
                "text": "Interessa saber qual a sua impressão sobre as instalações, sobre os Cuidadores, e se tiver alguma opinião gostaríamos de conhecê-la.",
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichText0id47413430e147 = new voltmx.ui.RichText({
                "bottom": 10,
                "centerX": "50%",
                "id": "RichText0id47413430e147",
                "isVisible": true,
                "left": "16dp",
                "linkSkin": "defRichTextLink",
                "skin": "RichTextNormalArial100",
                "text": "Agradecemos que responda às questões a seguir, podendo acrescentar, livremente, alguma outra de seu interesse.",
                "top": "10dp",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0fd6dfe80fafe4a.add(RichText0i2986006fe8f4d, RichText0c6a1c71b24cb44, RichText0bac21d7eabb64e, RichText0id47413430e147);
            var ButtonSqaured = new voltmx.ui.Button({
                "bottom": "10%",
                "centerX": "50%",
                "focusSkin": "ButtonSqrdSkinFocus",
                "height": "40dp",
                "id": "ButtonSqaured",
                "isVisible": true,
                "left": "10dp",
                "onClick": controller.AS_Button_he687de6c41b498d93c2d0c591a4b0ee,
                "right": "10dp",
                "skin": "ButtonSqrdSkinNormal",
                "text": "Iniciar",
                "width": "25%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "nav.FlexContainer0ab0fc83d79d44f": {
                    "centerX": "",
                    "left": 70,
                    "right": "0dp"
                },
                "nav.FlexContainer0db719fda9e144b": {
                    "layoutType": voltmx.flex.FREE_FORM
                },
                "nav.FlexContainer0h13fb7371bfe48": {
                    "centerX": "",
                    "left": "0dp"
                },
                "nav.Image0e45ade2c62da44": {
                    "centerX": "",
                    "left": "0dp"
                },
                "nav": {
                    "centerX": "50%",
                    "height": "70dp",
                    "width": "90%"
                }
            }
            this.add(nav, FlexContainer0fd6dfe80fafe4a, ButtonSqaured);
        };
        return [{
            "addWidgets": addWidgetsfrmStart,
            "enabledForIdleTimeout": false,
            "id": "frmStart",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": true,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "Pesquisas"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});