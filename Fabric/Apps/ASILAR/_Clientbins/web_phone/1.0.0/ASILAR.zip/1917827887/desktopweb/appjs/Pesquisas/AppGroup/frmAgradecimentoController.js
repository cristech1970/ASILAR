define("Pesquisas/AppGroup/userfrmAgradecimentoController", {
    //Type your controller code here 
});
define("Pesquisas/AppGroup/frmAgradecimentoControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Pesquisas/AppGroup/frmAgradecimentoController", ["Pesquisas/AppGroup/userfrmAgradecimentoController", "Pesquisas/AppGroup/frmAgradecimentoControllerActions"], function() {
    var controller = require("Pesquisas/AppGroup/userfrmAgradecimentoController");
    var controllerActions = ["Pesquisas/AppGroup/frmAgradecimentoControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
